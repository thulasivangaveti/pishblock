import os
import pickle
import pandas as pd
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB

# Load the labeled email data
data = pd.read_csv('data/sample_emails.csv')  # Ensure it has 'text' and 'label' columns
X = data['text']
y = data['label']

# Vectorize the text data using TF-IDF
vectorizer = TfidfVectorizer(stop_words='english')
X_vectorized = vectorizer.fit_transform(X)

# Train the model using Naive Bayes
model = MultinomialNB()
model.fit(X_vectorized, y)

# Ensure 'model/' directory exists
os.makedirs('model', exist_ok=True)

# Save the trained model and vectorizer
with open('model/spam_classifier.pkl', 'wb') as model_file:
    pickle.dump(model, model_file)

with open('model/vectorizer.pkl', 'wb') as vectorizer_file:
    pickle.dump(vectorizer, vectorizer_file)

print("✅ Model and vectorizer saved to /model/")
