# 📧 Fraud Mail Detector

This project automatically detects and deletes fraudulent/spam emails from your Gmail using a machine learning model. Supports both CLI and GUI modes.

---

## ✅ Features

- Gmail OAuth2 login
- ML model (Naive Bayes + TF-IDF)
- Deletes fraud emails from inbox
- CLI script and Tkinter GUI app
- Easy to train on your own dataset

---

## 📁 Project Structure
raud_mail_detector/ ├── credentials.json # OAuth2 credentials from Google Cloud ├── token.pickle # Auto-generated Gmail token ├── model/ │ ├── spam_classifier.pkl # Trained ML model │ └── vectorizer.pkl # TF-IDF vectorizer ├── data/ │ └── sample_emails.csv # Your labeled training data ├── utils/ │ ├── gmail_api.py │ ├── email_utils.py │ └── detector.py ├── gui/ │ └── app.py ├── train_model.py # Train spam classifier ├── scan_and_delete.py # Scan and delete via CLI └── README.md



---

## 🚀 Setup Instructions

### 1. Clone the repository
```bash
git clone <your-repo-url>
cd fraud_mail_detector


pip install -r requirements.txt

