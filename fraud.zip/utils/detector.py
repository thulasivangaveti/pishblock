import pickle
from sklearn.feature_extraction.text import TfidfVectorizer
from sklearn.naive_bayes import MultinomialNB

def load_model():
    with open('model/spam_classifier.pkl', 'rb') as model_file:
        model = pickle.load(model_file)
    
    with open('model/vectorizer.pkl', 'rb') as vec_file:
        vectorizer = pickle.load(vec_file)
    
    return model, vectorizer

def is_fraud(subject, body):
    model, vectorizer = load_model()

    # Preprocess and vectorize the subject and body of the email
    text = subject + " " + body
    vectorized_text = vectorizer.transform([text])

    # Predict using the trained model
    prediction = model.predict(vectorized_text)

    # 1 for fraudulent, 0 for safe
    return prediction[0] == 1
