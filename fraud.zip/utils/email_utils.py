from googleapiclient.discovery import build

def extract_email_content(service, msg_id):
    try:
        # Fetch the email by message ID
        msg = service.users().messages().get(userId='me', id=msg_id).execute()

        # Extract the email body and subject
        payload = msg['payload']
        headers = payload['headers']
        subject = next(header['value'] for header in headers if header['name'] == 'Subject')
        body = ''

        if 'parts' in payload:
            for part in payload['parts']:
                if part['mimeType'] == 'text/plain':
                    body = part['body']['data']
                    break

        return subject, body

    except Exception as error:
        print(f"Error extracting content: {error}")
        return '', ''
