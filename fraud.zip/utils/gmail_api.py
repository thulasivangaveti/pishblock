import os.path
import pickle
from google.auth.transport.requests import Request
from google_auth_oauthlib.flow import InstalledAppFlow
from googleapiclient.discovery import build

SCOPES = ['https://www.googleapis.com/auth/gmail.modify']

def authenticate_gmail():
    creds = None

    # Load token if it exists
    if os.path.exists('token.pickle'):
        with open('token.pickle', 'rb') as token:
            creds = pickle.load(token)

    # If no token or it's expired
    if not creds or not creds.valid:
        if creds and creds.expired and creds.refresh_token:
            creds.refresh(Request())
        else:
            flow = InstalledAppFlow.from_client_secrets_file(
                'credentials.json', SCOPES)
            creds = flow.run_local_server(port=0)

        # Save token for later use
        with open('token.pickle', 'wb') as token:
            pickle.dump(creds, token)

    service = build('gmail', 'v1', credentials=creds)
    return service

def fetch_all_messages(service):
    # Fetch up to 100 messages
    results = service.users().messages().list(userId='me', maxResults=100).execute()
    messages = results.get('messages', [])
    return messages

def get_or_create_label(service, label_name):
    try:
        # Get all labels
        labels = service.users().labels().list(userId='me').execute()

        # Check if the label already exists
        for label in labels['labels']:
            if label['name'] == label_name:
                return label  # Return existing label

        # If label doesn't exist, create it
        label_object = {
            'name': label_name,
            'labelListVisibility': 'labelShow',
            'messageListVisibility': 'show'
        }

        new_label = service.users().labels().create(userId='me', body=label_object).execute()
        return new_label  # Return newly created label

    except Exception as error:
        print(f"An error occurred while getting or creating label: {error}")
        return None
