# Import necessary methods
from utils.gmail_api import authenticate_gmail, fetch_all_messages, get_or_create_label
from utils.email_utils import extract_email_content
from utils.detector import is_fraud

def scan_and_delete():
    try:
        # Authenticate and fetch messages
        service = authenticate_gmail()
        messages = fetch_all_messages(service)

        if not messages:
            print("📭 No messages found.")
            return

        fraud_count = 0
        safe_count = 0
        deleted_count = 0

        for msg in messages:
            msg_id = msg['id']
            subject, body = extract_email_content(service, msg_id)

            if is_fraud(subject, body):
                # Handle fraud: label and/or delete
                print(f"⚠️ FRAUD DETECTED: {subject}")
                # Create or get the "FRAUDULENT" label
                label = get_or_create_label(service, 'FRAUDULENT')
                if label:
                    service.users().messages().modify(
                        userId='me',
                        id=msg_id,
                        body={'addLabelIds': [label['id']]}
                    ).execute()
                    print(f"✔️ Labeled as FRAUDULENT: {subject}")

                # Optionally delete the message
                service.users().messages().delete(userId='me', id=msg_id).execute()
                print(f"🗑️ DELETED: {subject}")
                deleted_count += 1
                fraud_count += 1
            else:
                print(f"✅ SAFE: {subject}")
                safe_count += 1

        # Print summary
        print(f"✅ Scanned {len(messages)} emails: {fraud_count} fraud detected, {safe_count} safe, {deleted_count} deleted.")

    except Exception as e:
        print(f"Error: {e}")

if __name__ == '__main__':
    scan_and_delete()
