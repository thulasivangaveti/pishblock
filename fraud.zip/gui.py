import tkinter as tk
from tkinter import messagebox
from utils.gmail_api import authenticate, fetch_messages
from utils.email_utils import get_email_content
from utils.detector import is_fraud

def scan():
    output.delete('1.0', tk.END)
    try:
        service = authenticate()
        messages = fetch_messages(service)

        if not messages:
            output.insert(tk.END, "📭 No messages found.\n")
            return

        for msg in messages:
            msg_id = msg['id']
            subject, body = get_email_content(service, msg_id)

            if is_fraud(subject, body):
                service.users().messages().delete(userId='me', id=msg_id).execute()
                output.insert(tk.END, f"🗑️ DELETED: {subject}\n", 'fraud')
            else:
                output.insert(tk.END, f"✅ SAFE: {subject}\n", 'safe')

    except Exception as e:
        messagebox.showerror("Error", str(e))

# GUI setup
root = tk.Tk()
root.title("Fraud Mail Detector")
root.geometry("700x500")

tk.Label(root, text="📧 Gmail Fraud Scanner", font=("Helvetica", 16)).pack(pady=10)

scan_btn = tk.Button(root, text="🔍 Scan Gmail", command=scan, bg="#4CAF50", fg="white", padx=20, pady=10)
scan_btn.pack()

output = tk.Text(root, wrap=tk.WORD)
output.tag_config('fraud', foreground='red')
output.tag_config('safe', foreground='green')
output.pack(expand=True, fill='both', padx=10, pady=10)

root.mainloop()
