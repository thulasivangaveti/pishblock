import pandas as pd

# Common phishing-style email examples
phishing_emails = [
    "Your account has been suspended due to suspicious activity. Click here to verify.",
    "Urgent: Verify your bank login now to avoid restrictions.",
    "You’ve won a free iPhone! Enter your details to claim.",
    "Reset your password immediately to secure your account.",
    "Unusual login attempt detected. Click to review your account.",
    "Your PayPal account has been locked. Update billing info.",
    "Congratulations! You've been selected for a $1000 gift card.",
    "We are unable to process your payment. Please verify your credit card.",
    "Netflix subscription expired. Click here to reactivate.",
    "Final warning: your account will be deactivated if you don’t respond."
]

# Create DataFrame of phishing samples
df_phishing = pd.DataFrame({
    "text": phishing_emails,
    "label": [1] * len(phishing_emails)
})

# Load existing or start new
try:
    df_existing = pd.read_csv("data/sample_emails.csv")
    df_combined = pd.concat([df_existing, df_phishing], ignore_index=True)
except FileNotFoundError:
    df_combined = df_phishing

# Save back to file
df_combined.to_csv("data/sample_emails.csv", index=False)
print("✅ Phishing samples added to data/sample_emails.csv")
